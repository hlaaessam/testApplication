package org.codeforiraq.testapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView mytextView;
    TextView mytextView2;



    Button mybutton;
    Button secbutton;
    Button thirdbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        mytextView = findViewById(R.id.textView);
        mytextView2 = findViewById(R.id.textView2);











        mybutton=findViewById(R.id.button);
        secbutton=findViewById(R.id.button2);
        thirdbutton=findViewById(R.id.button4);

        thirdbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this , CalculatorActivity.class);
                startActivity(intent);
            }
        });




        mybutton.setText(R.string.myname);
        mybutton.setBackgroundColor(Color.WHITE);
        mybutton.setTextColor(Color.GRAY);


        secbutton.setText(R.string.secname);
        secbutton.setTextColor(Color.GRAY);
        secbutton.setBackgroundColor(Color.WHITE);

        secbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mytextView2.setText(R.string.thirdname);
                mytextView2.setBackgroundColor(Color.WHITE);
                mytextView2.setTextColor(Color.BLUE);
            }


        });


    }




    public void ClickMyButton(View view){
        mytextView.setText(R.string.thirdname);
        mytextView.setBackgroundColor(Color.WHITE);
        mytextView.setTextColor(Color.GRAY);
    }

}