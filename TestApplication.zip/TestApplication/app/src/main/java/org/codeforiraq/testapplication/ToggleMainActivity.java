package org.codeforiraq.testapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ToggleMainActivity extends AppCompatActivity {

    private TextView togtextview;
    private ToggleButton togbutton;

    Button movebutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toggle);

        togbutton=findViewById(R.id.toggleButton);
        movebutton =findViewById(R.id.sbutton);


        togtextview=findViewById(R.id.togtext);


        togbutton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if(b){
                    togtextview.setVisibility(View.VISIBLE);
                    togtextview.setText("wifi on");
                }else{
                    togtextview.setVisibility(View.VISIBLE);
                    togtextview.setText("wifi off");
                }

            }
        });

//        movebutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent5= new Intent( ToggleMainActivity.this , SwitchCheckboxActivities.class);
//                startActivity(intent5);
//            }
//        });


        movebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 =new Intent(ToggleMainActivity.this ,SwitchCheckboxActivities.class);
                startActivity(intent5);
            }
        });
    }
}