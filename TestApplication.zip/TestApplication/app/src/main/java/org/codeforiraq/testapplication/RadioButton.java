package org.codeforiraq.testapplication;

import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

public class RadioButton extends AppCompatActivity {

    private RadioGroup grbutton;
    private android.widget.RadioButton rbutton;

    TextView mytextView;
    Button mobutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_radiobutton);

        mobutton=findViewById(R.id.sbutton);

        grbutton =findViewById(R.id.radioGroup);

        mytextView= findViewById(R.id.textView3);





        grbutton.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                rbutton=findViewById(i);

                switch (rbutton.getId()){

                    case R.id.radioButton2:{
                        mytextView.setVisibility(View.VISIBLE);
                        mytextView.setText("pizza");
                    } break;

                    case R.id.radioButton3:{
                        mytextView.setVisibility(View.VISIBLE);
                        mytextView.setText("hamburger");
                    } break;

                    case R.id.radioButton4:{
                        mytextView.setVisibility(View.VISIBLE);
                        mytextView.setText("steak");
                    } break;


                }
            }


        });


        mobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                try {
                    Intent intent3 = new Intent(RadioButton.this, ToggleMainActivity.class);
                    startActivity(intent3);

//                    Log.d("log", "intent finished");
//                }catch (Exception e){
//                    System.out.println("this is the exception  :  "+e.toString());
//                }
            }
        });
    }
}