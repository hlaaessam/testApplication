package org.codeforiraq.testapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

public class Calander extends AppCompatActivity {
    private Button mvbutton;
//    private RadioGroup gbutton;
//    private android.widget.RadioButton rbbutton;
//    private View radiobutton1;
//    private View radiobutton2;
//    private View radiobutton3;
//    private View radiobutton4;

    private AlertDialog.Builder alertbuild;

    private CheckBox time1;
    private CheckBox time2;
    private CheckBox time3;
    private Button nextbutton;

    private CalendarView calenderview ;
    private Calander calander;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calander);


        // page title
        getSupportActionBar().setTitle("Calender");
        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Calenderview declaration

        calenderview=findViewById(R.id.calendarViewid);



       //group Radiobutton declaration
//        gbutton=findViewById(R.id.grbutton2);



        // buttons declaration
        mvbutton =findViewById(R.id.mbutton4);
        nextbutton=findViewById(R.id.nextbutton1);

        // checkboxs
        time1=findViewById(R.id.checkBoxc1);
        time2=findViewById(R.id.checkBoxc2);
        time3=findViewById(R.id.checkBoxc3);

        time1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                time2.setChecked(false);
                time3.setChecked(false);
            }
        });

        time2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                time1.setChecked(false);
                time3.setChecked(false);
            }
        });

        time3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                time2.setChecked(false);
                time1.setChecked(false);


            }
        });




        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( time1.isChecked()){


                    alertbuild=new AlertDialog.Builder(Calander.this);


                        alertbuild.setTitle("your appoinment : ");
                        alertbuild.setMessage("from 10 to 11 Am");
                        alertbuild.setCancelable(false);
                        alertbuild.setPositiveButton("yes",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Calander.this.finish();


                            }
                        });

                        alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.cancel();

                            }
                        });

                        AlertDialog dialog= alertbuild.create();
                        dialog.show();


                }

                else if ( time2.isChecked()){





                    alertbuild=new AlertDialog.Builder(Calander.this);


                    alertbuild.setTitle("your appoinment : ");
                    alertbuild.setMessage("from 11 to 12 Am");
                    alertbuild.setCancelable(false);
                    alertbuild.setPositiveButton("yes",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Calander.this.finish();

                        }
                    });

                    alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.cancel();

                        }
                    });

                    AlertDialog dialog= alertbuild.create();
                    dialog.show();


                }
                else if ( time3.isChecked()){



                    alertbuild=new AlertDialog.Builder(Calander.this);


                    alertbuild.setTitle("your appoinment : ");
                    alertbuild.setMessage("from 1 to 2 Am");
                    alertbuild.setCancelable(false);
                    alertbuild.setPositiveButton("yes",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Calander.this.finish();

                        }
                    });

                    alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.cancel();

                        }
                    });

                    AlertDialog dialog= alertbuild.create();
                    dialog.show();

                }
            }
        });





//        mvbutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//        });

        calenderview.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
//                String mydate="Year : " + i+ "_"+ "Month : " + i1 + "_"+"Day : " + i2 ;

                int i3=i1+1;
                String mydate= i+ "_" + i3 + "_" + i2 ;
                Toast.makeText(Calander.this, " "+mydate, Toast.LENGTH_SHORT).show();
            }
        });






//        radiobutton1=findViewById(R.id.radioButton6);
//        radiobutton2=findViewById(R.id.radioButton7);
//        radiobutton3=findViewById(R.id.radioButton8);
//        radiobutton4=findViewById(R.id.radioButton9);


//        gbutton.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup radioGroup, int i) {
//
//
////                if(radiobutton1.callOnClick()){
////
////
////                }
//
//                rbbutton=findViewById(i);
//
//
//                switch (rbbutton.getId()){
//
//                    case R.id.radioButton6:{
//                        mvbutton.setBackgroundColor(Color.GRAY);
////                        alertbuild=new AlertDialog.Builder(Calander.this);
////
////                        alertbuild.setTitle("your appoinment : ");
////                        alertbuild.setMessage("from 10 to 11 Am");
////                        alertbuild.setCancelable(false);
////                        alertbuild.setPositiveButton("yes", new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////                                dialog.cancel();
////
////                            }
////                        });
////
////                        alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////
////                                Calander.this.finish();
////
////                            }
////                        });
////
////                        AlertDialog dialog= alertbuild.create();
////                        dialog.show();
//
//
//
//
//                    } break;
//
//                    case R.id.radioButton7:{
//                        mvbutton.setBackgroundColor(Color.WHITE);
//
////                        alertbuild=new AlertDialog.Builder(Calander.this);
////                        alertbuild.setTitle("your appoinment : ");
////                        alertbuild.setMessage("from 11 to 12 Pm");
////                        alertbuild.setCancelable(false);
////                        alertbuild.setPositiveButton("yes", new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////                                dialog.cancel();
////
////                            }
////                        });
////
////                        alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////
////                                Calander.this.finish();
////
////                            }
////                        });
////
////                        AlertDialog dialog= alertbuild.create();
////                        dialog.show();
//
//
//
//                    } break;
//
//                    case R.id.radioButton8:{
//
//                    mvbutton.setBackgroundColor(Color.BLACK);
////                        alertbuild=new AlertDialog.Builder(Calander.this);
////                        alertbuild.setTitle("your appoinment : ");
////                        alertbuild.setMessage("from 1 to 2 Pm");
////                        alertbuild.setCancelable(false);
////                        alertbuild.setPositiveButton("yes", new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////                                dialog.cancel();
////
////                            }
////                        });
////
////                        alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////
////                                Calander.this.finish();
////
////                            }
////                        });
////
////                        AlertDialog dialog= alertbuild.create();
////                        dialog.show();
////
////
//                    } break;
//                    case R.id.radioButton9:{
//                        mvbutton.setBackgroundColor(Color.GREEN);
////                        alertbuild=new AlertDialog.Builder(Calander.this);
////                        alertbuild.setTitle("your appoinment : ");
////                        alertbuild.setMessage("from 2 to 3 Pm");
////                        alertbuild.setCancelable(false);
////                        alertbuild.setPositiveButton("yes", new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////                                dialog.cancel();
////
////                            }
////                        });
////
////                        alertbuild.setNegativeButton( "No",new DialogInterface.OnClickListener() {
////                            @Override
////                            public void onClick(DialogInterface dialog, int which) {
////
////                                Calander.this.finish();
////
////                            }
////                        });
////
////                        AlertDialog dialog= alertbuild.create();
////                        dialog.show();
////
////
//                    } break;
////
////
//                }
//
//
//            }
//        });
    }


}