package org.codeforiraq.testapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class RatingbarActivity extends AppCompatActivity {

    private TextView ratingtext;
    private RatingBar ratingstar;
    private Button showbutton;
    private Button mvobutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratingbar);

        // page title
        getSupportActionBar().setTitle("Ratingbar");
        // to show back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //textview
        ratingtext=findViewById(R.id.ratingtext);
        //ratingbar
        ratingstar=findViewById(R.id.ratingBar);

        //buttons
        showbutton=findViewById(R.id.showbuttonratingbar);
        mvobutton =findViewById(R.id.mbutton2);

        showbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ratingtext.setVisibility(View.VISIBLE);
                String totalstars=ratingstar.getNumStars() + "";
                String rating =ratingstar.getRating() + "";
                ratingtext.setText("total stars are "+totalstars+"\n"+ "Rating is" + rating );

                Toast.makeText(RatingbarActivity.this, "your result :" + rating, Toast.LENGTH_SHORT).show();
            }
        });

        mvobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent6=new Intent(RatingbarActivity.this, Calander.class);
                startActivity(intent6);
            }
        });
    }
}