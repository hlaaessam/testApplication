package org.codeforiraq.testapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {
    Button mysum , mbutton;
    EditText mynumber1 , mynumber2;
    TextView myresult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculator);



        mysum=findViewById(R.id.sum);
        mbutton=findViewById(R.id.button3);


        mynumber1=findViewById(R.id.number1);
        mynumber2=findViewById(R.id.number2);

        myresult=findViewById(R.id.result);


        mysum.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {

                if((TextUtils.isDigitsOnly(mynumber1.getText().toString()) &&
                   TextUtils.isDigitsOnly(mynumber2.getText().toString()) ) &&
                        (!TextUtils.isEmpty(mynumber1.getText().toString()) &&
                         !TextUtils.isEmpty(mynumber2.getText().toString()) )){

                    double num1=Double.parseDouble(mynumber1.getText().toString());
                    double num2=Double.parseDouble(mynumber2.getText().toString());

                    myresult.setText("Result : "+ ( num1 + num2 ) );

                }
                else {
                    myresult.setText("please put number.");
                }




            }
        });

        mbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(CalculatorActivity.this , RadioButton.class);
                startActivity(intent2);
            }
        });

    }
}