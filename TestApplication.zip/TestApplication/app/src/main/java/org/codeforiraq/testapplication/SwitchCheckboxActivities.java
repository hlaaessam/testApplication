package org.codeforiraq.testapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class SwitchCheckboxActivities extends AppCompatActivity {

    private Button mvbutton;


    private TextView switchtext;
    private Switch switchbutton;


    private TextView chtextview;
    private Button showbutton;
    private CheckBox chjava;
    private CheckBox chpython;
    private CheckBox chphp;
    private CheckBox checkc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switchchekbox);

        // declaration textviews
        switchtext =findViewById(R.id.stextview);
        chtextview=findViewById(R.id.checkboxtextV);

        // declaration buttons
        switchbutton=findViewById(R.id.sbutton);
        showbutton=findViewById(R.id.showbutton);

        mvbutton=findViewById(R.id.mbutton1);


        // declaration checkboxes
        chjava=findViewById(R.id.checkBoxjava);
        chpython=findViewById(R.id.checkBoxpython);
        chphp=findViewById(R.id.checkBoxphp);
        checkc=findViewById(R.id.checkBoxc1);



        //function switch button
        switchbutton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    switchtext.setText("wifi on");
                } else {
                    switchtext.setText("wifi off");
                }
            }
        });



        //function checkbox
        showbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 StringBuilder stringschoose= new StringBuilder();
//                 stringschoose.append( chjava.getText().toString() + chjava.isChecked() +"\n");
//                 stringschoose.append(chpython.getText().toString() + chpython.isChecked() +"\n" );
//                 stringschoose.append(chphp.getText().toString() + chphp.isChecked() +"\n" );
//                 stringschoose.append(checkc.getText().toString() + checkc.isChecked() +"\n" );




                if(chjava.isChecked()){
                    stringschoose.append(chjava.getText().toString() + "\n");
                }
                if(chpython.isChecked()){
                    stringschoose.append(chpython.getText().toString() + "\n");
                }
                if(chphp.isChecked()){
                    stringschoose.append(chphp.getText().toString() + "\n");
                }
                if(checkc.isChecked()){
                    stringschoose.append(checkc.getText().toString() + "\n" );
                }

                chtextview.setText(stringschoose);




            }
        });


         //moving
        mvbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4=new Intent(SwitchCheckboxActivities.this, RatingbarActivity.class);
                startActivity(intent4);
            }
        });


    }
}